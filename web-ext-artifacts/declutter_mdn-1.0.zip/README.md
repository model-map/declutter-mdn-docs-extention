# declutter-mdn-docs-extention

A firefox extension to declutter mdn docs pages

Next-steps:

    - Add a toggle button
